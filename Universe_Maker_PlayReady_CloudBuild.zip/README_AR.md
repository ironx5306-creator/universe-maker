# مشروع Android — صانع المجموعة الشمسية

هذا المشروع يحوّل نسخة HTML الحالية من اللعبة إلى تطبيق Android بسيط باستخدام WebView.

## فتحه وبناؤه
1. افتح المجلد في Android Studio.
2. انتظر انتهاء Gradle Sync.
3. شغّل التطبيق على هاتف أو محاكي.
4. للنشر على Google Play استخدم Build > Generate Signed Bundle / APK ثم اختر Android App Bundle (AAB).
5. أنشئ مفتاح توقيع (keystore) واحفظه بأمان.
6. ارفع ملف AAB الناتج إلى Google Play Console.

Package name: com.example.solarsystem
Version: 1.0 (versionCode 1)

## ملاحظات
- اللعبة الحالية موجودة في app/src/main/assets/index.html.
- لا يحتاج التطبيق إلى صلاحية الإنترنت لتشغيل اللعبة الحالية.
- قبل النشر النهائي يفضّل إضافة أيقونة، شاشة بداية، سياسة خصوصية عند الحاجة، واختبار اللعبة على عدة أحجام شاشات.
