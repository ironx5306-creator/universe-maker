# تجهيز Universe Maker للنشر على Google Play

- تم ضبط `compileSdk` و`targetSdk` إلى 36.
- تم تغيير معرّف الحزمة إلى `com.universemaker.solarsystem`.
- أضيفت أيقونة تشغيل من ملف الهوية المرفق.
- لبناء AAB: افتح المشروع في Android Studio ثم:
  Build → Generate Signed Bundle / APK → Android App Bundle
- أنشئ Keystore خاصًا بك واحفظه في مكان آمن.
- ارفع ملف AAB الناتج إلى Play Console.

ملاحظة: معرّف الحزمة يجب أن يكون متاحًا وغير مستخدم مسبقًا في Google Play؛ إذا كان مستخدمًا، غيّره قبل أول نشر.
